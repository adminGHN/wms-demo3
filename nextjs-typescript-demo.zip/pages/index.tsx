import React from "react";

export default function Home() {
  return (
    <div style={{ padding: "40px", fontFamily: "sans-serif" }}>
      <h1>Hello from Next.js with TypeScript!</h1>
      <p>This project is ready to deploy 🚀</p>
    </div>
  );
}
